﻿namespace ATMService.Configuration
{
    public interface IConfiguration
    {
        string GetLogPath();
    }
}
