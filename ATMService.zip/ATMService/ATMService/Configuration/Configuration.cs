﻿using System.Configuration;

namespace ATMService.Configuration
{
    class ATMConfiguration : IConfiguration
    {
        public string GetLogPath()
        {
            return ConfigurationManager.AppSettings["LogPath"];
        }
    }
}
