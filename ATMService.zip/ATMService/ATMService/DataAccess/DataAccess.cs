﻿using ATMService.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ATMService.DataAccess
{
    public class DataAccess : IDataAccess
    {
        private List<CardCredential> credentials;
        private List<UserProfile> Profiles;
        private List<Account> Accounts;

        private List<Atm> ATMS;

        public DataAccess()
        {
            credentials = new List<CardCredential>();
            Profiles = new List<UserProfile>();
            Accounts = new List<Account>();
            ATMS = new List<Atm>();
            PopulateAtms();
            PopulateUserCardCredentials();
            PopulateUserProfiles();
            PopulateAccounts();
        }

        private void PopulateAtms()
        {
            ATMS.Add(new Atm("ABCD", "ABCD", "HSR", 500000));
            ATMS.Add(new Atm("EFGH", "EFGH", "Indira Nagar", 500000));
            ATMS.Add(new Atm("IJKL", "IJKL", "Sarjapur", 500000));
            ATMS.Add(new Atm("MNOP", "MNOP", "Koramangala", 500000));
            ATMS.Add(new Atm("QRST", "QRST", "Ejipura", 500000));
        }

        private void PopulateAccounts()
        {
            Accounts.Add(new Account("A1234", 50000, 1000, 100000));
            Accounts.Add(new Account("A4567", 100000, 1000, 100000));
            Accounts.Add(new Account("A8910", 1000000, 1000, 100000));
            Accounts.Add(new Account("A1112", 20000, 1000, 100000));
            Accounts.Add(new Account("A1314", 30000, 1000, 100000));
        }

        private void PopulateUserCardCredentials()
        {
            credentials.Add(new CardCredential("1234", "1234"));
            credentials.Add(new CardCredential("4567", "4567"));
            credentials.Add(new CardCredential("8910", "8910"));
            credentials.Add(new CardCredential("1112", "1112"));
            credentials.Add(new CardCredential("1314", "1314"));
        }

        private void PopulateUserProfiles()
        {
            Profiles.Add(new UserProfile("user1", "", "", "A1234", "1234"));
            Profiles.Add(new UserProfile("user2", "", "", "A4567", "4567"));
            Profiles.Add(new UserProfile("user3", "", "", "A8910", "8910"));
            Profiles.Add(new UserProfile("user4", "", "", "A1112", "1112"));
            Profiles.Add(new UserProfile("user5", "", "", "A1314", "1314"));
        }

        public AuthToken GenerateAuthToken(UserProfile user, string atmId)
        {
            AuthToken token = null;

            foreach (var item in Profiles.Where(o => o.CardNo == user.CardNo))
            {
                item.Session = Guid.NewGuid().ToString();
                token = new AuthToken(item.AccountNo, item.Session, atmId, item.Name);
                break;
            }

            return token;
        }

        public UserProfile GetProfileForUser(string user)
        {
            UserProfile profile = null;
            foreach (var item in Profiles.Where(o => o.CardNo == user))
            {
                item.Session = Guid.NewGuid().ToString();
                profile = item;
                break;
            }
            return profile;
        }
        public bool AuthenticateUser(string user, string password, string atmId)
        {
            var userDetail = from cred in credentials
                             where (cred.CardNo == user && cred.Pin == password)
                             select cred;
            return (userDetail.Count<CardCredential>() > 0);
        }

        public double CheckFund(string AccountNo)
        {
            var Account = from a in Accounts
                          where a.AccountNo == AccountNo
                          select a;

            return Account.FirstOrDefault().Balance;
        }

        public bool DepositeFund(string AccountNo, double amount)
        {
            bool ret = false;
            foreach (var item in Accounts.Where(o => o.AccountNo == AccountNo))
            {
                item.Balance += amount;
                ret = true;
                break;
            }
            return ret;

        }

        public bool WithdrawFund(string AccountNo, double amount)
        {
            bool ret = false;
            foreach (var item in Accounts.Where(o => o.AccountNo == AccountNo))
            {
                if (item.Balance - amount > 0)
                {
                    item.Balance -= amount;
                    ret = true;
                }
                break;
            }
            return ret;
        }

        public bool ValidateAtm(string atmId, string password)
        {
            var AtmDetail = from atm in ATMS
                            where (atm.AtmId == atmId && atm.Password == password)
                            select atm;
            if (AtmDetail != null && AtmDetail.Count() > 0)
                return true;

            return false;
        }

        public bool IsValidAuthToken(string AccountNo, string session)
        {
            if (session == Profiles.Where(o => o.AccountNo == AccountNo).FirstOrDefault().Session)
                return true;
            else
                return false;
        }

        public bool LogOut(string AccountNo)
        {
            bool ret = false;
            foreach (var item in Profiles.Where(o => o.AccountNo == AccountNo))
            {
                item.Session = null;
                ret = true;
                break;
            }
            return ret;
        }


        public bool DebitAtmAccount(string atmId, double amount)
        {
            bool ret = false;
            foreach (var item in ATMS.Where(o => o.AtmId == atmId))
            {
                if (item.CashBalance - amount > 0)
                {
                    item.CashBalance -= amount;
                    ret = true;
                }
                else
                    ret = false;
                break;
            }
            return ret;
        }

        public bool CreditAtmAccount(string atmId, double amount)
        {
            bool ret = false;
            foreach (var item in ATMS.Where(o => o.AtmId == atmId))
            {
                item.CashBalance += amount;
                ret = true;
                break;
            }
            return ret;
        }
    }
}