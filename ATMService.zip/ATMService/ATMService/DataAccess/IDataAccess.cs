using ATMService.Model;
using System.Collections.Generic;

namespace ATMService.DataAccess
{
    public interface IDataAccess
    {
        AuthToken GenerateAuthToken(UserProfile user, string atmId);
        UserProfile GetProfileForUser(string user);
        bool AuthenticateUser(string user, string password, string atmId);

        double CheckFund(string AccountNo);

        bool DepositeFund(string AccountNo, double amount);

        bool WithdrawFund(string AccountNo, double amount);

        bool ValidateAtm(string atmId, string password);        

        bool DebitAtmAccount(string atmId, double amount);

        bool CreditAtmAccount(string atmId, double amount);

        bool IsValidAuthToken(string AccountNo, string session);

        bool LogOut(string AccountNo);

    }
}
