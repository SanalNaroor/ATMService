﻿using ATMService.DataAccess;
using ATMService.Model;
using System.ServiceModel;

namespace ATMService.Repository
{
    public class Atmrepository : IAtmRepository
    {
        private IDataAccess _dataAccess;

        public Atmrepository(IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }
        public double CheckFund(string AccountNo, string session)
        {
            if (!_dataAccess.IsValidAuthToken(AccountNo, session))
                throw new FaultException("User Is not authorized");

            return _dataAccess.CheckFund(AccountNo);
        }

        public bool DepositeFund(string AccountNo, string session, double Amount)
        {
            if (!_dataAccess.IsValidAuthToken(AccountNo, session))
                throw new FaultException("User Is not authorized");

            return _dataAccess.DepositeFund(AccountNo, Amount);
        }


        public AuthToken Login(string user, string password, string atmId)
        {
            AuthToken token = null;
            if (_dataAccess.AuthenticateUser(user, password, atmId))
            {
                UserProfile profile = _dataAccess.GetProfileForUser(user);
                if (profile == null)
                    throw new FaultException("user Profile not found");
                token = _dataAccess.GenerateAuthToken(profile, atmId);
            }

            return token;
        }

        public bool LogOut(string AccountNo, string session)
        {
            if (!_dataAccess.IsValidAuthToken(AccountNo, session))
                throw new FaultException("User Is not authorized");

            return _dataAccess.LogOut(AccountNo);
        }

        public bool UpdateAtmAccount(string AtmId, double amount, bool IsDeposit)
        {
            return _dataAccess.UpdataAtmAccount(AtmId, amount, IsDeposit);
        }

        public bool ValidateAtm(string AtmId, string Password)
        {
            return _dataAccess.ValidateAtm(AtmId, Password);
        }

        public bool WithdrawFund(string AccountNo, string session, double Amount)
        {
            if (!_dataAccess.IsValidAuthToken(AccountNo, session))
                throw new FaultException("User Is not authorized");


            return _dataAccess.WithdrawFund(AccountNo, Amount);
        }
    }
}