﻿using ATMService.Model;

namespace ATMService.Repository
{
    public interface IAtmRepository
    {
        double CheckFund(string AccountNo, string session);

        bool DepositeFund(string AccountNo, string session, double Amount);

        AuthToken Login(string user, string password, string atmId);

        bool LogOut(string AccountNo, string session);

        bool UpdateAtmAccount(string AtmId, double amount, bool IsDeposit);

        bool ValidateAtm(string AtmId, string Password);

        bool WithdrawFund(string AccountNo, string session, double Amount);
    }
}
