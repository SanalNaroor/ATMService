﻿using ATMService.Interface;
using ATMService.Model;
using ATMService.Repository;
using System.ServiceModel;
namespace ATMService
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class AtmService : IAtmService
    {
        private IAtmRepository _repository;

        public AtmService(IAtmRepository repo)
        {
            _repository = repo;
        }

        public double CheckFund(string AccountNo, string session)
        {
            return _repository.CheckFund(AccountNo, session);
        }

        [OperationBehavior(TransactionScopeRequired = true)]
        public bool DepositeFund(string AccountNo, string session, double Amount)
        {
            return _repository.DepositeFund(AccountNo, session, Amount);
        }


        public AuthToken Login(string user, string password, string atmId)
        {
            return _repository.Login(user, password, atmId);
        }

        public bool LogOut(string AccountNo, string session)
        {
            return _repository.LogOut(AccountNo, session);
        }

        public bool UpdateAtmAccount(string AtmId, double amount, bool IsDeposit)
        {
            return _repository.UpdateAtmAccount(AtmId, amount, IsDeposit);
        }

        public bool ValidateAtm(string AtmId, string Password)
        {
            return _repository.ValidateAtm(AtmId, Password);
        }

        public bool WithdrawFund(string AccountNo, string session, double Amount)
        {
            return _repository.WithdrawFund(AccountNo, session, Amount);
        }


    }
}
