﻿using ATMService.Model;
using System.ServiceModel;

namespace ATMService.Interface
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IAtmService
    {
        [OperationContract]
        AuthToken Login(string user, string password, string atmId);

        [OperationContract]
        double CheckFund(string AccountNo, string session);

        [OperationContract]
        [TransactionFlow(TransactionFlowOption.Allowed)]
        bool DepositeFund(string AccountNo, string session, double Amount);

        [OperationContract]
        [TransactionFlow(TransactionFlowOption.Allowed)]
        bool WithdrawFund(string AccountNo, string session, double Amount);

        [OperationContract]
        bool ValidateAtm(string AtmId, string Password);

        [OperationContract]
        [TransactionFlow(TransactionFlowOption.Allowed)]
        bool UpdateAtmAccount(string AtmId, double amount, bool IsDeposit);

        [OperationContract]
        bool LogOut(string AccountNo, string session);
    }


}
