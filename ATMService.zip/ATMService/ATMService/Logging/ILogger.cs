﻿namespace ATMService.Logging
{
    public interface ILogger
    {
        void LogTransaction(string log);
    }
}
