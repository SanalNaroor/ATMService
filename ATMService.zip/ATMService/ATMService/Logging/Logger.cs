﻿using ATMService.Configuration;
using System;
using System.Collections.Generic;
using System.IO;

namespace ATMService.Logging
{
    public class Logger : ILogger
    {
        string _logPath;
        public Logger(IConfiguration config)
        {
            _logPath = config.GetLogPath();
        }
        public void LogTransaction(string log)
        {
            List<String> Lines = new List<string>();
            Lines.Add(DateTime.Now.ToString() + log);
            if (!Directory.Exists(_logPath))
            {
                Directory.CreateDirectory(_logPath);
            }

            string LogFilePath = _logPath + string.Format("\\AtmServiceLog{0}.txt", DateTime.Now.DayOfYear.ToString() + DateTime.Now.Year.ToString());

            if (!File.Exists(LogFilePath))
            {
                File.Create(LogFilePath).Close();

            }
            File.AppendAllLines(LogFilePath, Lines);
        }
    }
}
