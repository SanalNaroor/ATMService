﻿using System.Runtime.Serialization;

namespace ATMService.Model
{
    [DataContract]
    public class AuthToken
    {
        public AuthToken(string accountNo, string session, string atmId, string name)
        {
            AccountNo = accountNo;
            Session = session;
            AtmId = atmId;
            Name = name;
        }
        [DataMember]
        public string AccountNo { get; set; }
        [DataMember]
        public string Session { get; set; }
        [DataMember]
        public string AtmId { get; set; }
        [DataMember]
        public string Name { get; set; }
    }
}