﻿namespace ATMService.Model
{
    public class Account
    {
        public Account(string accountNo, double balance, double minBalance, double limit)
        {
            AccountNo = accountNo;
            Balance = balance;
            MinimumBalance = minBalance;
            WithdrawlLimit = limit;
        }
        public string AccountNo { get; set; }
        public double Balance { get; set; }
        public double MinimumBalance { get; set; }
        public double WithdrawlLimit { get; set; }
    }
}