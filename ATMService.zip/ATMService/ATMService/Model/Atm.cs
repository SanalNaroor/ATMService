﻿namespace ATMService.Model
{
    public class Atm
    {
        public Atm(string atmId, string password, string location, double cashBalance)
        {
            AtmId = atmId;
            Password = password;
            Location = location;
            CashBalance = cashBalance;
        }
        public string AtmId { get; set; }
        public string Password { get; set; }
        public string Location { get; set; }
        public double CashBalance { get; set; }

    }
}