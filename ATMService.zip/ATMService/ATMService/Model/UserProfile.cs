﻿namespace ATMService.Model
{
    public class UserProfile
    {
        public UserProfile(string name, string contact, string address, string accountNo, string cardNo)
        {
            Name = name;
            Contact = contact;
            Address = address;
            AccountNo = accountNo;
            CardNo = cardNo;
        }

        public UserProfile(string name, string contact, string address, string accountNo, string cardNo, string session)
        {
            Name = name;
            Contact = contact;
            Address = address;
            AccountNo = accountNo;
            CardNo = cardNo;
            Session = session;
        }
        public string Name { get; set; }
        public string Contact { get; set; }
        public string Address { get; set; }
        public string AccountNo { get; set; }
        public string CardNo { get; set; }
        public string Session { get; set; }
    }
}