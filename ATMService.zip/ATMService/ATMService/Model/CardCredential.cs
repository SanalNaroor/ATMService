﻿namespace ATMService.Model
{
    public class CardCredential
    {
        public CardCredential(string User, string Password)
        {
            CardNo = User;
            Pin = Password;

        }
        public string CardNo { get; set; }
        public string Pin { get; set; }
    }
}