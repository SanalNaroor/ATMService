﻿using System.Configuration;

namespace AtmConsole
{
    class ATMConfiguration : IConfiguration
    {
        public string GetLogPath()
        {
            return ConfigurationManager.AppSettings["LogPath"];
        }
    }
}
