﻿using System;

namespace AtmConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            IConfiguration config = new ATMConfiguration();
            ILogger logger = new Logger(config);
            Atm atm = new Atm(logger);
            Console.ReadLine();
        }
    }
}
