﻿namespace AtmConsole
{
    class UserCredential
    {
        public UserCredential()
        {

        }
        public UserCredential(string user, string password)
        {
            User = user;
            Password = password;
        }
        public string User { get; set; }
        public string Password { get; set; }
    }
}
