﻿using System;

namespace AtmConsole
{
    class AtmConsoleUI
    {
        public static string mt = "\t\t\t\t";
        public static string st = "\t\t  ";
        public static string xst = "\t\t";

        public static void header()
        {
            Console.Clear();
            Console.WriteLine("\n\n\n\n\t\t===============================================");
            Console.WriteLine(mt + "State Bank");
            Console.WriteLine("\t\t===============================================");
        }

        public static void main_header()
        {
            Console.Clear();
            Console.WriteLine("\n\n\t\t\t" + xst + DateTime.Now + "\n\t\t===============================================");
            Console.WriteLine(mt + "State Bank");
            Console.WriteLine("\t\t===============================================");

        }

        public static void footer()
        {
            Console.WriteLine("\t\t===============================================");
        }

        public static void UI_home()
        {
            header();
            Console.WriteLine("\n\n" + st + "\tState Bank ATM FACILTIY MAKES");
            Console.WriteLine(mt + "LIFE SIMPLE\n\n");
            footer();
            Console.Write(st + "Press <any> key to continue:");
            Console.ReadKey();

        }


        public static void UI_error(String error)
        {
            header();
            Console.WriteLine("\n\n" + st + " ERROR: " + error + "\n\n");
            footer();
            Console.Write(st + "Press <any> key to continue:");
            Console.ReadKey();

        }

        public static void UI_msgbox(String msg)
        {
            header();
            Console.WriteLine("\n\n" + st + msg + "\n\n");
            footer();
            Console.Write(st + "Press <any> key to continue:");
            Console.ReadKey();

        }

        public static int OptionsScreen(ref AtmUser user)
        {
            AtmConsoleUI.main_header();

            Console.WriteLine(xst + "\tWelcome: " + user.Name + ".\n");
            Console.WriteLine(xst + "1.Deposit.\t\t2.Withdrawal.\n");
            Console.WriteLine(xst + "3.Balance INQ.\t\t4.Logout.\n");

            AtmConsoleUI.footer();
            Console.Write(st + "Enter your choice: ");
            int option = 0;
            int.TryParse(Console.ReadLine(), out option);
            return option;
        }
        public static void LoginScreen(ref AtmUser user)
        {
            AtmConsoleUI.header();
            Console.Write(AtmConsoleUI.st + "Enter your CARD no: ");
            user.CardNo = Console.ReadLine();
            Console.Write(st + "Enter your PIN: ");
            string password = "";
            ConsoleKeyInfo key;

            do
            {
                key = Console.ReadKey(true);

                if (key.Key != ConsoleKey.Backspace || key.Key != ConsoleKey.Enter)
                {
                    password += key.KeyChar;
                    Console.Write("*");
                }
                else
                {
                    if ((password.Length - 1) != -1)
                    {
                        password = password.Remove(password.Length - 1);
                        Console.Write("\b \b");
                    }
                }
            }
            while (key.Key != ConsoleKey.Enter);
            password.Substring(0, password.Length);
            user.Password = password.Substring(0, password.Length - 1);
        }




        //public static void Main()
        //{
        //    ATM a = new ATM();

        //    SUDO_MAIN: // from MAIN MENUS logic // to avoid re-initilialize ATM class!!  
        //    int getAtm_no = 0;
        //    UI_home(); // Homepage  
        //               // Login Page logic - Do not mess it up!!  
        //    LOGIN:
        //    int isValidLogin = UI_login(ref a, ref getAtm_no); // calls login UI which return integers   
        //    switch (isValidLogin)
        //    {
        //        case -1:
        //            UI_error("Alphabets Not Allowed");
        //            goto LOGIN;
        //        case 1:
        //            goto MAIN_MENU; // Goto Main Menus if valid user  
        //        case 2:
        //            UI_error("Invalid Password");
        //            goto LOGIN;
        //        case 3:
        //            UI_error("Invalid Account Number");
        //            goto LOGIN;
        //        default:
        //            UI_error("Something Wrong in GUI_login()!");
        //            Main();
        //            break;
        //    }


        //    //MAIN MENUS logic  
        //    MAIN:
        //    MAIN_MENU: // from Login Page  
        //    while (true)
        //    {
        //        mnuChoice = UI_main(ref getAtm_no); // call MAIN_UI  
        //        switch (mnuChoice)
        //        {
        //            case -1:
        //                UI_error("Alphabets Not Allowed");
        //                goto MAIN;
        //            case 1:
        //                a.deposit(getAtm_no);
        //                break;
        //            case 2:
        //                a.withdraw(getAtm_no);
        //                break;
        //            case 3:
        //                a.balance(getAtm_no);
        //                break;
        //            case 4:
        //                a.tnfr_fund(getAtm_no);
        //                break;
        //            case 5:
        //                a.mini_stmt(getAtm_no, false); //false for full n no.of tranx recordings   
        //                break;
        //            case 6:
        //                a.chng_pin(getAtm_no);
        //                break;
        //            case 7:
        //                a.mini_stmt(getAtm_no, true); //true for last 5 noof tranx recordings   
        //                break;
        //            case 8:
        //                UI_msgbox("Thankyou for visting SPB ATM.\n");
        //                GC.SuppressFinalize(a);//Garbage Collection  
        //                goto SUDO_MAIN;
        //            default:
        //                UI_error("Invalid Choice! [1-8].");
        //                Main();
        //                break;
        //        }
        //    }
        //}
    }
}



