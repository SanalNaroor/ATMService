﻿namespace AtmConsole
{
    public interface ILogger
    {
        void LogTransaction(string log);
    }
}
