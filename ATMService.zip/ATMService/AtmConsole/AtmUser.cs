﻿namespace AtmConsole
{
    public class AtmUser
    {
        public AtmUser()
        {

        }
        public AtmUser(string accountNo, string session, string name)
        {
            AccountNo = accountNo;
            Session = session;
            Name = name;

        }
        public string AccountNo { get; set; }
        public string Session { get; set; }
        public string Name { get; set; }
        public string CardNo { get; set; }
        public string Password { get; set; }
    }
}