﻿namespace AtmConsole
{
    public interface IConfiguration
    {
        string GetLogPath();
    }
}
