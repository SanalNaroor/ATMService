﻿using System;

namespace AtmConsole
{
    public class Atm
    {
        private ILogger _logger;
        public Atm(ILogger logger)
        {
            _logger = logger;
            client = new ServiceReference1.AtmServiceClient();
            IsValidAtmSession = client.ValidateAtm("ABCD", "ABCD");
            BussinessLogic();
        }

        private ServiceReference1.AtmServiceClient client = null;
        private AtmUser user = null;
        private bool IsValidAtmSession = false;



        private void BussinessLogic()
        {
            while (true)
            {
                if (IsValidAtmSession)
                {
                    if (user == null)
                    {
                        user = new AtmUser();
                        AtmConsoleUI.UI_home();
                        AtmConsoleUI.LoginScreen(ref user);
                    }
                    login();
                }
            }
        }

        private void AtmFunction()
        {
            try
            {
                switch (AtmConsoleUI.OptionsScreen(ref user))
                {
                    case 1:
                        {
                            Console.Write(AtmConsoleUI.st + "Please Enter the amount you want to deposit:");
                            string str = Console.ReadLine();
                            var amt = double.Parse(str.Trim());
                            if (amt > 0)
                            {
                                client.DepositeFund(user.AccountNo, user.Session, amt);
                                client.UpdateAtmAccount("ABCD", amt, true);
                                AtmConsoleUI.UI_msgbox(string.Format("Deposit was successfull balance is: {0}", client.CheckFund(user.AccountNo, user.Session)));
                                _logger.LogTransaction(string.Format("Successfully deposited amount {0} to Account {1}", amt, user.AccountNo));
                            }
                            else
                            {
                                AtmConsoleUI.UI_msgbox(string.Format("Please enter a valid amount"));
                            }

                            break;
                        }
                    case 2:
                        {
                            Console.Write(AtmConsoleUI.st + "Please Enter the amount you want to Withdraw:");
                            string str = Console.ReadLine();
                            var amt = double.Parse(str.Trim());
                            if (amt > 0)
                            {
                                if (client.UpdateAtmAccount("ABCD", amt, false))
                                {
                                    if (client.WithdrawFund(user.AccountNo, user.Session, amt))
                                    {
                                        AtmConsoleUI.UI_msgbox(string.Format("Current balance is: {0}", client.CheckFund(user.AccountNo, user.Session)));
                                        _logger.LogTransaction(string.Format("Successfully dispensed amount {0} to Account {1}", amt, user.AccountNo));
                                    }
                                    else
                                    {
                                        client.UpdateAtmAccount("ABCD", amt, true);
                                        AtmConsoleUI.UI_msgbox(string.Format("Insufficient Balance"));
                                        _logger.LogTransaction(string.Format("Transaction rolledback as Account {0} had insufficient balance", user.AccountNo));
                                    }


                                }
                                else
                                {
                                    AtmConsoleUI.UI_msgbox(string.Format("Unable to Dispense Cash"));
                                    _logger.LogTransaction(string.Format("Unable to Dispense Cash to the user {0}", user.AccountNo));
                                }
                            }
                            else
                            {
                                AtmConsoleUI.UI_msgbox(string.Format("Please enter a valid amount"));
                            }

                            break;
                        }
                    case 3:
                        {
                            AtmConsoleUI.UI_msgbox(string.Format("Consolidated balance in your Account is: {0}", client.CheckFund(user.AccountNo, user.Session)));
                            break;
                        }
                    case 4:
                        {
                            client.LogOut(user.AccountNo, user.Session);
                            _logger.LogTransaction(string.Format("{0} Logged out of Statebank ATM after accessing the Account number {1}", user.Name, user.AccountNo));
                            user = null;
                            break;
                        }
                    default:
                        {
                            break;
                        }

                }
            }
            catch (Exception)
            {
                AtmConsoleUI.UI_msgbox(string.Format("Something went wrong please try again"));
            }

        }


        public void login()
        {
            if (string.IsNullOrEmpty(user.Session))
            {
                ServiceReference1.AuthToken token = client.Login(user.CardNo, user.Password, "ABCD");
                if (token != null)
                {
                    user.AccountNo = token.AccountNo;
                    user.Session = token.Session;
                    user.Name = token.Name;
                    _logger.LogTransaction(string.Format("{0} Logged in to the Statebank ATM to acces the Account number {1}", user.Name, user.AccountNo));
                }
                else
                {
                    AtmConsoleUI.UI_msgbox(string.Format("Invalid Credentials Please Try Again"));
                    user = null;
                    return;
                }
            }
            AtmFunction();

        }



    }
}
