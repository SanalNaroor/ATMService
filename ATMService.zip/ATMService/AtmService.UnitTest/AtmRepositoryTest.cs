﻿using ATMService.DataAccess;
using ATMService.Model;
using ATMService.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.ServiceModel;

namespace AtmService.UnitTest
{
    [TestClass]
    public class AtmRepositoryTest
    {
        [TestMethod]
        public void RepositoryLoginTestWithBadUser()
        {
            Mock<IDataAccess> dataAccess = new Mock<IDataAccess>();

            dataAccess.Setup(x => x.AuthenticateUser(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(false);

            Atmrepository repository = new Atmrepository(dataAccess.Object);
            var token = repository.Login("Test", "password", "atmId");

            Assert.AreEqual(null, token);
        }

        [TestMethod]
        public void RepositoryLoginTestWithGoodUser()
        {
            Mock<IDataAccess> dataAccess = new Mock<IDataAccess>();

            dataAccess.Setup(x => x.AuthenticateUser(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(true);
            dataAccess.Setup(x => x.GetProfileForUser(It.IsAny<string>())).Returns(new UserProfile("user1", "", "", "A1234", "1234", Guid.NewGuid().ToString()));
            dataAccess.Setup(x => x.GenerateAuthToken(It.IsAny<UserProfile>(), It.IsAny<string>()));

            Atmrepository repository = new Atmrepository(dataAccess.Object);
            var token = repository.Login("Test", "password", "atmId");

            dataAccess.Verify(x => x.GenerateAuthToken(It.IsAny<UserProfile>(), It.IsAny<string>()));//called atleast once
        }

        [TestMethod]
        [ExpectedException(typeof(FaultException))]
        public void RepositoryLoginTestWithUserHavingMissingProfile()
        {
            Mock<IDataAccess> dataAccess = new Mock<IDataAccess>();

            dataAccess.Setup(x => x.AuthenticateUser(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(true);

            Atmrepository repository = new Atmrepository(dataAccess.Object);
            var token = repository.Login("Test", "password", "atmId");
        }

        [TestMethod]
        [ExpectedException(typeof(FaultException))]
        public void LogOutTestForUserNotAlreadyLoggedIn()
        {
            Mock<IDataAccess> dataAccess = new Mock<IDataAccess>();
            dataAccess.Setup(x => x.IsValidAuthToken(It.IsAny<string>(), It.IsAny<string>())).Returns(false);
            Atmrepository repository = new Atmrepository(dataAccess.Object);

            repository.LogOut("", "");

        }

        [TestMethod]
        public void LogOutTestForUserAlreadyLoggedIn()
        {
            Mock<IDataAccess> dataAccess = new Mock<IDataAccess>();
            dataAccess.Setup(x => x.IsValidAuthToken(It.IsAny<string>(), It.IsAny<string>())).Returns(true);
            dataAccess.Setup(x => x.LogOut(It.IsAny<string>()));
            Atmrepository repository = new Atmrepository(dataAccess.Object);

            repository.LogOut("", "");

            dataAccess.Verify(x => x.LogOut(It.IsAny<string>()));//called atleast once
        }

        [TestMethod]
        public void CheckFundTestForUserAlreadyLoggedIn()
        {
            Mock<IDataAccess> dataAccess = new Mock<IDataAccess>();
            dataAccess.Setup(x => x.IsValidAuthToken(It.IsAny<string>(), It.IsAny<string>())).Returns(true);
            dataAccess.Setup(x => x.CheckFund(It.IsAny<string>()));
            Atmrepository repository = new Atmrepository(dataAccess.Object);

            repository.CheckFund("A1234", "");

            dataAccess.Verify(x => x.CheckFund(It.IsAny<string>()));//called atleast once
        }

        [TestMethod]
        [ExpectedException(typeof(FaultException))]
        public void CheckFundTestForUserNotAlreadyLoggedIn()
        {
            Mock<IDataAccess> dataAccess = new Mock<IDataAccess>();
            dataAccess.Setup(x => x.IsValidAuthToken(It.IsAny<string>(), It.IsAny<string>())).Returns(false);
            dataAccess.Setup(x => x.CheckFund(It.IsAny<string>()));
            Atmrepository repository = new Atmrepository(dataAccess.Object);

            repository.CheckFund("A1234", "");
        }

        [TestMethod]
        public void DepositeFundTestForUserAlreadyLoggedIn()
        {
            Mock<IDataAccess> dataAccess = new Mock<IDataAccess>();
            dataAccess.Setup(x => x.IsValidAuthToken(It.IsAny<string>(), It.IsAny<string>())).Returns(true);
            dataAccess.Setup(x => x.DepositeFund(It.IsAny<string>(), It.IsAny<double>()));
            Atmrepository repository = new Atmrepository(dataAccess.Object);

            repository.DepositeFund("A1234", "", 1000);

            dataAccess.Verify(x => x.DepositeFund(It.IsAny<string>(), It.IsAny<double>()));//called atleast once
        }

        [TestMethod]
        [ExpectedException(typeof(FaultException))]
        public void DepositeFundTestForUserNotAlreadyLoggedIn()
        {
            Mock<IDataAccess> dataAccess = new Mock<IDataAccess>();
            dataAccess.Setup(x => x.IsValidAuthToken(It.IsAny<string>(), It.IsAny<string>())).Returns(false);
            dataAccess.Setup(x => x.DepositeFund(It.IsAny<string>(), It.IsAny<double>()));
            Atmrepository repository = new Atmrepository(dataAccess.Object);

            repository.DepositeFund("A1234", "", 1000);
        }


        [TestMethod]
        public void WithdrawFundTestForUserAlreadyLoggedIn()
        {
            Mock<IDataAccess> dataAccess = new Mock<IDataAccess>();
            dataAccess.Setup(x => x.IsValidAuthToken(It.IsAny<string>(), It.IsAny<string>())).Returns(true);
            dataAccess.Setup(x => x.WithdrawFund(It.IsAny<string>(), It.IsAny<double>()));
            Atmrepository repository = new Atmrepository(dataAccess.Object);

            repository.WithdrawFund("A1234", "", 1000);

            dataAccess.Verify(x => x.WithdrawFund(It.IsAny<string>(), It.IsAny<double>()));//called atleast once
        }

        [TestMethod]
        [ExpectedException(typeof(FaultException))]
        public void WithdrawFundTestForUserNotAlreadyLoggedIn()
        {
            Mock<IDataAccess> dataAccess = new Mock<IDataAccess>();
            dataAccess.Setup(x => x.IsValidAuthToken(It.IsAny<string>(), It.IsAny<string>())).Returns(false);
            dataAccess.Setup(x => x.WithdrawFund(It.IsAny<string>(), It.IsAny<double>()));
            Atmrepository repository = new Atmrepository(dataAccess.Object);

            repository.WithdrawFund("A1234", "", 1000);
        }

        [TestMethod]
        public void UpdateAtmAccountForDepositeScenario()
        {
            Mock<IDataAccess> dataAccess = new Mock<IDataAccess>();
            dataAccess.Setup(x => x.CreditAtmAccount(It.IsAny<string>(), It.IsAny<double>()));


            Atmrepository repository = new Atmrepository(dataAccess.Object);

            repository.UpdateAtmAccount("", 1000, true);

            dataAccess.Verify(x => x.CreditAtmAccount(It.IsAny<string>(), It.IsAny<double>()));
        }

        [TestMethod]
        public void UpdateAtmAccountForWithdrawlScenario()
        {
            Mock<IDataAccess> dataAccess = new Mock<IDataAccess>();
            dataAccess.Setup(x => x.DebitAtmAccount(It.IsAny<string>(), It.IsAny<double>()));


            Atmrepository repository = new Atmrepository(dataAccess.Object);

            repository.UpdateAtmAccount("", 1000, false);

            dataAccess.Verify(x => x.DebitAtmAccount(It.IsAny<string>(), It.IsAny<double>()));
        }


    }
}
